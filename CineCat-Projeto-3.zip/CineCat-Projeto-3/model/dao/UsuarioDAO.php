<?php
    class UsuarioDAO {
        public function read() {
            try {
                $query = BD::getConexao() ->prepare("SELECT * FROM usuario");
                }
                catch("PDOException $e") {
                    echo "Erro #2: " . $e->getMessage();
            }
        }
    }